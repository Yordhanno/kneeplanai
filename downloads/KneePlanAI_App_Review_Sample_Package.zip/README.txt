KneePlanAI Standard - App Review Sample

Build: 4.0.2 (2)
Platform: macOS

The included DICOM image is de-identified and contains no patient name, patient ID, date of birth, accession number, institution, or private DICOM tags. Pixel data and Pixel Spacing are preserved.

Review workflow:
1. Launch KneePlanAI Standard.
2. Select Open radiograph and open KneePlanAI_App_Review_Sample_Anonymized.dcm.
3. Select the right side.
4. Place or adjust the anatomical landmarks and joint lines.
5. Open Results to review the calculated measurements.
6. Open Report to generate the PDF report.
7. Open Analysis to view the descriptive CPAK strategy table.

No registration, login credentials, subscription, purchase, external hardware, or internet connection is required.

The app is a manual measurement and documentation support tool for trained healthcare professionals. Users must verify all landmarks, calibration, and results before clinical use.
